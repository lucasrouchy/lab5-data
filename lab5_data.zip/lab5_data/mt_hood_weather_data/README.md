This data covers 2 years of weather forecasts for Mt. Hood, Oregon observed at 3 different locations.

filename: `<location>_<elevation>_<start date>_<end date>`