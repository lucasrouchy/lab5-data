This data covers 2 years of avalanche forecasts for Mt. Hood, Oregon.

filename: `<avalanche center>_<start date>_<end date>`